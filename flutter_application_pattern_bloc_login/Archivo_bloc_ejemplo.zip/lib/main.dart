import 'package:flutter/material.dart';

void main() {
  runApp(
    MainApp(
      userNameController: TextEditingController(),
      passwordController: TextEditingController(),
    ),
  );
}

class MainApp extends StatelessWidget {
  final TextEditingController userNameController;
  final TextEditingController passwordController;

  const MainApp({
    super.key,
    required this.userNameController,
    required this.passwordController,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Column(
          children: [
            SizedBox(height: 40),
            Center(child: Text('Welcome to the Login App')),
            SizedBox(height: 20),
            TextField(
              controller: userNameController,
              decoration: InputDecoration(
                labelText: 'Username',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(onPressed: () {}, child: Text('Login')),
          ],
        ),
      ),
    );
  }
}
